﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using CosmosGrapher.Classes;
using Newtonsoft.Json;

namespace Bsc_Smart_Semantic_Framework.LpgModels
{
    public class LpgCity : Vertex
    {
        public LpgCity() {}
    }
}
