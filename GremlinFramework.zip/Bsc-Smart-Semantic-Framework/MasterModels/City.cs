﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bsc_Smart_Semantic_Framework.MasterModels
{
    public class City
    {
        public City() {}

        public string buzz_id { get; set; }
        public string id { get; set; }
        public string name { get; set; }
    }
}
