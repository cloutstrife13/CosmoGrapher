﻿using System;
using System.Collections.Generic;
using System.Text;
using Gremlin.Net.Driver;

namespace CosmoGrapher.Interfaces
{
    public interface IStore
    {
    }
}
